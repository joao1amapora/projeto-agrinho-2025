let macieiraEstado = 0; // 0: broto, 1: pequena, 2: florida, 3: com maçãs
let contadorMacas = 0;
let botaoRegar;
let infoTexto = "";

function setup() {
  createCanvas(800, 600);
  background(135, 206, 235); // Céu azul

  // Botão para regar
  botaoRegar = createButton('Regar Macieira');
  botaoRegar.position(50, 550);
  botaoRegar.mousePressed(regarMacieira);

  // Botão para simular crescimento (para testes iniciais)
  let botaoCrescer = createButton('Fazer Crescer');
  botaoCrescer.position(200, 550);
  botaoCrescer.mousePressed(crescerMacieira);

  // Texto inicial do Agrinho
  infoTexto = "Bem-vindo ao Agrinho Maçã Mania! Vamos cuidar da nossa macieira!";
}

function draw() {
  background(135, 206, 235); // Limpa a tela a cada frame
  drawChao();
  drawMacieira();
  drawPontuacao();
  drawInfoAgrinho();
}

function drawChao() {
  fill(139, 69, 19); // Cor da terra
  rect(0, height - 100, width, 100);
  fill(34, 139, 34); // Cor da grama
  rect(0, height - 120, width, 20);
}

function drawMacieira() {
  // Tronco
  fill(100, 50, 0);
  rect(width / 2 - 20, height - 250, 40, 150);

  // De acordo com o estado da macieira, desenha as folhas/frutas
  if (macieiraEstado >= 1) { // Pequena, folhas verdes
    fill(0, 100, 0);
    ellipse(width / 2, height - 280, 100, 100);
  }
  if (macieiraEstado >= 2) { // Florida, adiciona flores
    fill(255, 192, 203); // Rosa claro
    ellipse(width / 2 - 30, height - 300, 30, 30);
    ellipse(width / 2 + 30, height - 300, 30, 30);
    ellipse(width / 2, height - 260, 30, 30);
  }
  if (macieiraEstado >= 3) { // Com maçãs
    fill(255, 0, 0); // Maçãs vermelhas
    ellipse(width / 2 - 40, height - 310, 25, 25);
    ellipse(width / 2 + 40, height - 310, 25, 25);
    ellipse(width / 2, height - 290, 25, 25);
    ellipse(width / 2 - 20, height - 270, 25, 25);
    ellipse(width / 2 + 20, height - 270, 25, 25);
  }
}

function drawPontuacao() {
  fill(0);
  textSize(24);
  text('Maçãs Colhidas: ' + contadorMacas, 20, 30);
}

function drawInfoAgrinho() {
  fill(0);
  textSize(18);
  textAlign(CENTER);
  text(infoTexto, width / 2, 50);
}

function regarMacieira() {
  // Aqui você pode adicionar lógica para o impacto da rega
  // Por exemplo, aumentar um medidor de umidade ou acelerar o crescimento
  infoTexto = "Você regou a macieira! Ela agradece.";
  // Poderia ter um temporizador ou um sistema de "saúde" da árvore
}

function crescerMacieira() {
  // Avança o estado da macieira
  if (macieiraEstado < 3) {
    macieiraEstado++;
    if (macieiraEstado == 1) infoTexto = "A macieira está crescendo! Que bom!";
    if (macieiraEstado == 2) infoTexto = "Olha as flores! Maçãs a caminho!";
    if (macieiraEstado == 3) infoTexto = "As maçãs estão amadurecendo! Hora de colher!";
  } else {
    // Se já está com maçãs, simula a colheita
    colherMacas();
  }
}

function colherMacas() {
  contadorMacas += 5; // Simula a colheita de algumas maçãs
  infoTexto = "Você colheu 5 maçãs frescas! Delícia!";
  // Resetar o estado da macieira para "florida" ou "pequena" após a colheita
  macieiraEstado = 2;
}

// Opcional: Adicionar interação para clicar nas maçãs para colher
function mousePressed() {
  // Se o mouse estiver sobre as maçãs e o estado for 3, colhe
  // (Precisaria de mais lógica para detectar a área das maçãs)
  // Por enquanto, o botão "Fazer Crescer" simula a colheita no estado 3
}